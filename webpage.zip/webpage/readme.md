# CV one-pager

## Snabbstart
1. Skapa en mapp och spara `index.html`, `robots.txt`, `sitemap.xml` i roten.
2. Öppna `index.html` i webbläsaren.

## Publicera
- GitHub Pages: Lägg filerna i en repo. Aktivera Pages (branch `main`, root).
- Netlify/Vercel: Dra-och-släpp mappen i deras dash. Inga byggsteg behövs.

## Uppdatera delningsbild
- Byt `og:image` i <head> till en extern bild-URL eller genererad banner.

## E-post & formulär
- E-post maskeras i JS. Vill du använda Formspree, skapa en form och byt `action`-URL.
